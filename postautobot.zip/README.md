# PostAutoBot

A lightweight server that lets your AI agent post to LinkedIn via a simple REST API.

---

## Quick Start

```bash
npm install
npm start
# Open http://localhost:3000
```

---

## Setup (3 steps)

### 1. Create a LinkedIn App
1. Go to https://www.linkedin.com/developers/apps → **Create app**
2. Under **Products**, add:
   - ✅ **Sign In with LinkedIn using OpenID Connect**
   - ✅ **Share on LinkedIn**
3. Under **Auth** → **OAuth 2.0 settings**, add redirect URL:
   ```
   http://localhost:3000/auth/callback
   ```
4. Copy your **Client ID** and **Client Secret**

### 2. Connect via Dashboard
1. Open http://localhost:3000
2. Paste your Client ID + Secret → **Save Credentials**
3. Click **Connect LinkedIn Account** → authorize on LinkedIn

### 3. Configure Your AI Agent
Use the API key shown in the dashboard.

---

## API Reference

### POST /api/post

Post to LinkedIn from your AI agent.

**Headers:**
```
x-api-key: <your_api_key>
Content-Type: application/json
```

**Body:**
```json
{
  "text": "Your post content here 🚀",
  "title": "Optional article title",
  "url": "https://yourblog.com/post",
  "visibility": "PUBLIC"
}
```

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `text` | string | ✅ Yes | Main post text |
| `title` | string | No | Article title (shown in link preview) |
| `url` | string | No | Link to full article |
| `visibility` | string | No | `PUBLIC` or `CONNECTIONS` (default: `PUBLIC`) |

**Success Response:**
```json
{
  "success": true,
  "post_id": "urn:li:share:1234567890",
  "post_url": "https://www.linkedin.com/feed/update/urn:li:share:1234567890"
}
```

---

## Example: Call from an AI Agent

```python
import requests

def post_to_linkedin(text, url=None, title=None):
    response = requests.post(
        "http://localhost:3000/api/post",
        headers={
            "x-api-key": "YOUR_API_KEY_HERE",
            "Content-Type": "application/json"
        },
        json={
            "text": text,
            "url": url,
            "title": title
        }
    )
    return response.json()

# Usage
post_to_linkedin(
    text="Just published a new post on async Python patterns! 🐍\n\nKey takeaways:\n- asyncio fundamentals\n- Real-world patterns\n- Performance tips",
    url="https://myblog.com/async-python",
    title="Async Python Patterns"
)
```

---

## Deploy to Production

When deploying (e.g. Railway, Render, Fly.io), set these env vars instead of using the UI:

```
LINKEDIN_CLIENT_ID=your_client_id
LINKEDIN_CLIENT_SECRET=your_client_secret
API_KEY=your_secure_api_key
PORT=3000
```

Update your redirect URL in LinkedIn app settings to match your production domain:
```
https://your-app.railway.app/auth/callback
```
